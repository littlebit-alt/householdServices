import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class BottomNav extends StatelessWidget {
  final int currentIndex;
  const BottomNav({super.key, required this.currentIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade200, width: 1)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, -2)),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _NavItem(
                icon: Icons.home_rounded, 
                label: 'Home', 
                index: 0, 
                current: currentIndex, 
                onTap: () {
                  // Use pushReplacement to avoid stacking the same page multiple times
                  if (currentIndex != 0) {
                    context.pushReplacement('/home');
                  }
                }
              ),
              _NavItem(
                icon: Icons.search_rounded, 
                label: 'Search', 
                index: 1, 
                current: currentIndex, 
                onTap: () {
                  if (currentIndex != 1) {
                    context.pushReplacement('/providers');
                  }
                }
              ),
              _NavItem(
                icon: Icons.calendar_today_rounded, 
                label: 'Bookings', 
                index: 2, 
                current: currentIndex, 
                onTap: () {
                  if (currentIndex != 2) {
                    context.pushReplacement('/bookings');
                  }
                }
              ),
              _NavItem(
                icon: Icons.person_rounded, 
                label: 'Profile', 
                index: 3, 
                current: currentIndex, 
                onTap: () {
                  if (currentIndex != 3) {
                    context.pushReplacement('/profile');
                  }
                }
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final int index;
  final int current;
  final VoidCallback onTap;
  const _NavItem({required this.icon, required this.label, required this.index, required this.current, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isActive = index == current;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFF0891B2).withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 22, color: isActive ? const Color(0xFF0891B2) : Colors.grey.shade400),
            const SizedBox(height: 3),
            Text(label, style: TextStyle(
              fontSize: 10,
              color: isActive ? const Color(0xFF0891B2) : Colors.grey.shade400,
              fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
            )),
          ],
        ),
      ),
    );
  }
}
import cv2
import mediapipe as mp
import pyuatogui
cap = cv2.VideoCapture(0)
hand_detector = mp.solutions.hands.Hands()
drawing_utils = mp.solutions.drawing_utils
screen_width, screen_height = pyautogui.size()
while True:
    _, frame = cap.read()
    frame = cv2.flip(frame, 1)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    output = hand_detector.process(rgb_frame)
    hands = output.multi_hand_landmarks
    if hands:
        for hand in hands:
            drawing_utils.draw_landmarks(frame, hand, mp.solutions.hands.HAND_CONNECTIONS)
            landmarks = hand.landmark
            index_finger_tip = landmarks[8]
            x = int(index_finger_tip.x * screen_width)
            y = int(index_finger_tip.y * screen_height)
            pyautogui.moveTo(x, y)
            thumb= landmarks[4]
            if abs(index.x-thumb.x) < 0.02 and abs(index.y-thumb.y) < 0.02:
                pyautogui.click()
                pyuatogui.sleep(1) # Prevent multiple clicks
    cv2.imshow("Hand controller", frame)
    if cv2.waitKey(1)  == ord('q'):
        break
    cap.release()
cv2.destroyAllWindows()
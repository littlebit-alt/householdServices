const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const prisma = require('../config/prisma');
const { sendOTPEmail } = require('../utils/email');

// ===== GENERATE OTP =====
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// ===== GENERATE TOKEN =====
const generateToken = (id, type) => {
  return jwt.sign(
    { id, type },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN }
  );
};

// ===== REGISTER =====
const register = async (req, res) => {
  try {
    const { fullName, email, phone, password } = req.body;

    // ── Validation ──────────────────────────────────────────────────────────
    if (!fullName || !email || !phone || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: 'Invalid email format' });
    }

    if (phone.replace(/\D/g, '').length < 7) {
      return res.status(400).json({ message: 'Invalid phone number' });
    }

    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters' });
    }
    // ────────────────────────────────────────────────────────────────────────

    // Check if email already exists
    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already in use' });
    }

    // Check if phone already exists
    const existingPhone = await prisma.user.findUnique({ where: { phone } });
    if (existingPhone) {
      return res.status(400).json({ message: 'Phone number already in use' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Generate OTP
    const otp = generateOTP();
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Create user
    const user = await prisma.user.create({
      data: {
        fullName,
        email,
        phone,
        password: hashedPassword,
        otp,
        otpExpiresAt,
      }
    });

    // Send OTP email — track whether it succeeded
    let emailSent = true;
    try {
      await sendOTPEmail(email, fullName, otp);
    } catch (emailError) {
      console.error('Email sending failed:', emailError.message);
      emailSent = false;
    }

    res.status(201).json({
      message: emailSent
        ? 'Registration successful! Please check your email for the OTP.'
        : 'Account created but email delivery failed. Please use resend OTP.',
      userId: user.id,
      emailSent,
    });

  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// ===== VERIFY OTP =====
const verifyOTP = async (req, res) => {
  try {
    const { userId, otp } = req.body;

    const user = await prisma.user.findUnique({ where: { id: parseInt(userId) } });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check OTP
    if (user.otp !== otp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    // Check OTP expiry
    if (new Date() > user.otpExpiresAt) {
      return res.status(400).json({ message: 'OTP has expired' });
    }

    // Mark user as verified
    await prisma.user.update({
      where: { id: user.id },
      data: {
        isVerified: true,
        otp: null,
        otpExpiresAt: null
      }
    });

    // Generate token
    const token = generateToken(user.id, 'user');

    res.json({
      message: 'Email verified successfully!',
      token,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
      }
    });

  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// ===== LOGIN =====
const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // Check if verified
    if (!user.isVerified) {
      return res.status(400).json({ message: 'Please verify your email first' });
    }

    // Check if active
    if (!user.isActive) {
      return res.status(400).json({ message: 'Your account has been deactivated' });
    }

    // Generate token
    const token = generateToken(user.id, 'user');

    res.json({
      message: 'Login successful!',
      token,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        avatar: user.avatar,
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// ===== FORGOT PASSWORD =====
const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      return res.status(404).json({ message: 'No account found with this email' });
    }

    // Generate OTP
    const otp = generateOTP();
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await prisma.user.update({
      where: { id: user.id },
      data: { otp, otpExpiresAt }
    });

    await sendOTPEmail(email, user.fullName, otp);

    res.json({ message: 'OTP sent to your email!', userId: user.id });

  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// ===== RESET PASSWORD =====
const resetPassword = async (req, res) => {
  try {
    const { userId, otp, newPassword } = req.body;

    const user = await prisma.user.findUnique({ where: { id: parseInt(userId) } });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.otp !== otp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    if (new Date() > user.otpExpiresAt) {
      return res.status(400).json({ message: 'OTP has expired' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword,
        otp: null,
        otpExpiresAt: null
      }
    });

    res.json({ message: 'Password reset successful!' });

  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// ===== ADMIN LOGIN =====
const adminLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    const admin = await prisma.admin.findUnique({ where: { email } });
    if (!admin) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const token = generateToken(admin.id, 'admin');

    res.json({
      message: 'Admin login successful!',
      token,
      admin: {
        id: admin.id,
        fullName: admin.fullName,
        email: admin.email,
        role: admin.role,
      }
    });

  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// ===== PROVIDER LOGIN =====
const providerLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const provider = await prisma.provider.findUnique({ where: { email } });
    if (!provider) return res.status(400).json({ message: 'Invalid email or password' });
    const isMatch = await bcrypt.compare(password, provider.password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid email or password' });
    if (!provider.isActive) return res.status(400).json({ message: 'Account deactivated' });
    const token = generateToken(provider.id, 'provider');
    res.json({
      message: 'Login successful!',
      token,
      provider: {
        id: provider.id,
        fullName: provider.fullName,
        email: provider.email,
        phone: provider.phone,
        avatar: provider.avatar,
        isVerified: provider.isVerified,
        rating: provider.rating,
        totalReviews: provider.totalReviews,
      }
    });
  } catch (error) {
    console.error('Provider login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  register,
  verifyOTP,
  login,
  forgotPassword,
  resetPassword,
  adminLogin,
  providerLogin
};
